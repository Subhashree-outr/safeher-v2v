# SaveHer - AI-Powered Women's Safety Backend (V1)

SaveHer is an AI-driven women's safety platform. This is **V1** of the agentic backend, focusing on a fully integrated **YOLO11 Vision Agent** orchestrated using **LangGraph** and **FastAPI**.

The system receives real-time camera frames, executes object detection to search for safety threat markers, passes evaluations to a Threat Fusion module, and triggers emergency alert protocols if threat thresholds are exceeded.

---

## Technical Stack
* **Python**: 3.12
* **Framework**: FastAPI
* **Orchestration**: LangGraph (StateGraph)
* **Computer Vision**: Ultralytics YOLO11
* **Image Processing**: OpenCV & NumPy

---

## Directory Structure

```text
save-herv1/
├── backend/
│   ├── agents/
│   │   ├── vision.py       # YOLO11 threat evaluation agent
│   │   ├── fusion.py       # Threat Fusion aggregator
│   │   ├── decision.py     # Rule-based decision agent
│   │   └── sos.py          # Emergency actions dispatcher
│   ├── api/
│   │   └── routes.py       # FastAPI telemetry router
│   ├── graph/
│   │   ├── state.py        # LangGraph State definitions
│   │   ├── supervisor.py   # Task routing supervisor
│   │   └── builder.py      # StateGraph compilation entrypoint
│   ├── models/
│   │   └── yolo.py         # YOLO11 inference wrapper
│   ├── utils/
│   │   ├── config.py       # Environment and system weights
│   │   └── logger.py       # Standard structured logging
│   ├── app.py              # FastAPI server entrypoint
│   └── requirements.txt    # Project dependencies
├── .gitignore
└── README.md