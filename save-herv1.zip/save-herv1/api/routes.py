from fastapi import APIRouter, HTTPException, File, UploadFile
from typing import Optional
from backend.graph.builder import build_workflow

router = APIRouter(prefix="/api/v1")
flow_graph = build_workflow()

@router.post("/telemetry")
async def post_telemetry_event(camera_frame: Optional[UploadFile] = File(None)):
    frame_bytes = None
    if camera_frame:
        frame_bytes = await camera_frame.read()

    initial_state = {
        "camera_frame": frame_bytes,
        "active_agents": [],
        "vision_result": None,
        "threat_score": 0.0,
        "decision": "SAFE",
        "actions": [],
        "history": []
    }

    try:
        final_state = await flow_graph.ainvoke(initial_state)
        return {
            "threat_score": final_state.get("threat_score"),
            "decision": final_state.get("decision"),
            "actions": final_state.get("actions", []),
            "history": final_state.get("history", []),
            "vision_summary": final_state.get("vision_result")
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))