from backend.graph.state import State

async def decision_node(state: State) -> dict:
    score = state.get("threat_score", 0.0)
    
    if score >= 81:
        decision = "SOS"
    elif score >= 61:
        decision = "WARNING"
    elif score >= 31:
        decision = "MONITOR"
    else:
        decision = "SAFE"

    return {
        "decision": decision,
        "history": state.get("history", []) + [f"Decision Agent resolved output: {decision}"]
    }