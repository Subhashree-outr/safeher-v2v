from backend.graph.state import State

async def threat_fusion_node(state: State) -> dict:
    vision = state.get("vision_result")
    if vision:
        score = vision["risk"]
        reason = f"Vision Agent reported: {vision['reason']}"
    else:
        score = 0.0
        reason = "No visual telemetry available."

    return {
        "threat_score": score,
        "history": state.get("history", []) + [f"Threat Fusion completed. Consolidated risk: {score}% | {reason}"]
    }