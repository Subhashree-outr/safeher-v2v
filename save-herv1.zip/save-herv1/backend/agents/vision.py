from datetime import datetime
from backend.graph.state import State
from backend.models.yolo import YOLO11Wrapper
from backend.utils.config import settings

yolo_model = YOLO11Wrapper(settings.YOLO_MODEL_PATH)

async def vision_agent_node(state: State) -> dict:
    frame = state.get("camera_frame")
    if not frame:
        return {"vision_result": None}
    
    detections = await yolo_model.detect_objects(frame)
    risk = 0.0
    reason = "No threat markers identified."
    classes = [d["label"].lower() for d in detections]
    
    if any(k in classes for k in ["knife", "scissors", "baseball bat", "gun"]):
        risk = 95.0
        reason = f"Aggressive weapon tool detected: {classes}."
    elif "person" in classes:
        person_count = classes.count("person")
        if person_count >= 3:
            risk = 60.0
            reason = f"Crowd detected in proximity ({person_count} individuals)."
        else:
            risk = 30.0
            reason = "Single individual presence detected."

    result = {
        "agent": "Vision",
        "risk": risk,
        "confidence": 0.88,
        "reason": reason,
        "details": {"detections": detections},
        "timestamp": datetime.utcnow().isoformat()
    }
    return {"vision_result": result}