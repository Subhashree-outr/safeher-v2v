import uvicorn
from fastapi import FastAPI
from backend.api.routes import router as api_router
from backend.utils.config import settings

app = FastAPI(title="SaveHer - Pure Vision Agent Backend")
app.include_router(api_router)

if __name__ == "__main__":
    uvicorn.run("backend.app:app", host=settings.HOST, port=settings.PORT, reload=True)