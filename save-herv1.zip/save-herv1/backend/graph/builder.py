from langgraph.graph import StateGraph, START, END
from backend.graph.state import State
from backend.graph.supervisor import supervisor_node
from backend.agents.vision import vision_agent_node
from backend.agents.fusion import threat_fusion_node
from backend.agents.decision import decision_node
from backend.agents.sos import sos_node

def build_workflow() -> StateGraph:
    workflow = StateGraph(State)

    workflow.add_node("supervisor", supervisor_node)
    workflow.add_node("vision_agent", vision_agent_node)
    workflow.add_node("threat_fusion_agent", threat_fusion_node)
    workflow.add_node("decision_agent", decision_node)
    workflow.add_node("sos_agent", sos_node)

    workflow.add_edge(START, "supervisor")
    workflow.add_edge("supervisor", "vision_agent")
    workflow.add_edge("vision_agent", "threat_fusion_agent")
    workflow.add_edge("threat_fusion_agent", "decision_agent")

    def evaluate_decision_outcome(state: State) -> str:
        if state.get("decision", "SAFE") == "SOS":
            return "sos_agent"
        return "end"

    workflow.add_conditional_edges(
        "decision_agent",
        evaluate_decision_outcome,
        {
            "sos_agent": "sos_agent",
            "end": END
        }
    )
    workflow.add_edge("sos_agent", END)

    return workflow.compile()