from typing import TypedDict, List, Dict, Any, Optional

class AgentResult(TypedDict, total=False):
    agent: str
    risk: float
    confidence: float
    reason: str
    details: Dict[str, Any]
    timestamp: str

class State(TypedDict):
    camera_frame: Optional[bytes]
    active_agents: List[str]
    vision_result: Optional[AgentResult]
    threat_score: float
    decision: str
    actions: List[str]
    history: List[str]