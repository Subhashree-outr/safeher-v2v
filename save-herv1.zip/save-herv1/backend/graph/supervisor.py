from backend.graph.state import State
from backend.utils.logger import logger

async def supervisor_node(state: State) -> dict:
    active_agents = []
    if state.get("camera_frame") is not None:
        active_agents.append("vision")

    logger.info(f"[Supervisor] Routing tasks: {active_agents}")
    return {
        "active_agents": active_agents,
        "history": state.get("history", []) + ["Supervisor activated Vision analysis."]
    }