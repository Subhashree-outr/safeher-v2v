import cv2
import numpy as np
from backend.utils.logger import logger

try:
    from ultralytics import YOLO
    HAS_YOLO = True
except ImportError:
    HAS_YOLO = False

class YOLO11Wrapper:
    def __init__(self, model_path: str):
        self.enabled = HAS_YOLO
        if self.enabled:
            try:
                self.model = YOLO(model_path)
                logger.info("YOLO11 loaded successfully.")
            except Exception as e:
                logger.warning(f"Failed to load YOLO11, entering mock mode: {e}")
                self.enabled = False
        else:
            logger.warning("ultralytics library not found. Running in mock vision mode.")

    async def detect_objects(self, frame_bytes: bytes) -> list:
        if not self.enabled:
            return self._mock_detect(frame_bytes)
        try:
            nparr = np.frombuffer(frame_bytes, np.uint8)
            img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            if img is None:
                return []
            
            results = self.model(img, verbose=False)
            detections = []
            for r in results:
                for box in r.boxes:
                    cls_id = int(box.cls[0])
                    label = self.model.names[cls_id]
                    confidence = float(box.conf[0])
                    detections.append({"label": label, "confidence": confidence})
            return detections
        except Exception as e:
            logger.error(f"YOLO11 execution error: {e}")
            return []

    def _mock_detect(self, frame_bytes: bytes) -> list:
        if len(frame_bytes) % 2 == 0:
            return [{"label": "knife", "confidence": 0.92}]
        return [{"label": "person", "confidence": 0.85}]